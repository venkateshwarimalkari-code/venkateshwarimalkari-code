`github.json` is written daily by `scripts/fetch_github_data.py` (via the profile-cards workflow).
`sample.json` is placeholder data, used only when you render locally before the first workflow run.
