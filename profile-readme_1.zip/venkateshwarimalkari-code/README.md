<img src="cards/hero.svg" width="100%" alt="Hey, I'm Venkateshwari Malkari: CSE AI & ML student turning “what if?” into “let’s try it!”">

<a href="https://linkedin.com/in/venkateshwari-85543b338"><img src="cards/tile-1.svg" width="32.5%" alt="LinkedIn: let's connect"></a>
<a href="https://instagram.com/venkateshwariii"><img src="cards/tile-2.svg" width="32.5%" alt="Instagram: @venkateshwariii"></a>
<a href="mailto:venkateshwarimalkari@gmail.com"><img src="cards/tile-3.svg" width="32.5%" alt="Email: venkateshwarimalkari@gmail.com"></a>

<img src="cards/activity.svg" width="100%" alt="My contributions per month over the last year, with current streak, longest streak, active days and busiest day">

<!-- cards:repos:start -->
<!-- cards:repos:end -->

<img src="cards/graph.svg" width="100%" alt="My GitHub contribution graph for the last year">

<!-- Cards are rendered by render_cards.py and refreshed daily by .github/workflows/profile-cards.yml -->
